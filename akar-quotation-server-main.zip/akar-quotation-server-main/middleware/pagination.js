const paginationMiddleware = (req, res, next) => {
  // Default pagination values
  const page = parseInt(req.query.page) || 1;
  const limit = parseInt(req.query.limit) || 10;
  const skip = (page - 1) * limit;

  // Add pagination info to request
  req.pagination = {
    page,
    limit,
    skip
  };

  next();
};

export default paginationMiddleware; 