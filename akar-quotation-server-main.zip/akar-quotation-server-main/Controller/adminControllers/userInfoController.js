import googleSecurityHeader from '../../services/googleSecurityHeader.js';

const SHEET_ID = process.env.QUOTE_SHEET_ID;

const userInfoController = async(req,res) => {
    const query = 'SELECT A ,B, C'
    const token = await googleSecurityHeader();

    const url = `https://docs.google.com/spreadsheets/d/${SHEET_ID}/gviz/tq?sheet=SalesTeam&tq=${query}&access_token=${token}`;
  
    try{
        const resu = await fetch(url);
        const text = await resu.text();
        const jsonText = text.replace(/^.*?\(/, "").slice(0, -2).replace(/\/\*.*?\*\//g,"").replace(/google.visualization.Query.setResponse\(/, "");
        const data = JSON.parse(jsonText);  
        const rows = data.table.rows.map(row => row.c.map(cell => (cell ? cell.v : null)));
        
        res.send(rows);
    }
    catch(e){
        console.log("data not found");
        console.log(e);
        
        res.send("data not found")
    }
}

export default userInfoController;