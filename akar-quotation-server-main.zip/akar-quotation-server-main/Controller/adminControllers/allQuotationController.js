import googleSecurityHeader from '../../services/googleSecurityHeader.js';

const SHEET_ID = process.env.QUOTE_SHEET_ID;

const allQuotationController = async (req, res) => {    
    const query = 'SELECT A ,B, G, C, L, BQ, BR'
    const { page, limit, skip } = req.pagination;
    const token = await googleSecurityHeader();

    const url = `https://docs.google.com/spreadsheets/d/${SHEET_ID}/gviz/tq?sheet=QuotationSheet&tq=${query}&access_token=${token}`;
  
    try {
        const resu = await fetch(url);
        const text = await resu.text();
        const jsonText = text.replace(/^.*?\(/, "").slice(0, -2).replace(/\/\*.*?\*\//g,"").replace(/google.visualization.Query.setResponse\(/, "");
        const data = JSON.parse(jsonText);  
        const allRows = data.table.rows.map(row => row.c.map(cell => (cell ? cell.v : null)));
        
        // Apply pagination
        const totalItems = allRows.length;
        const totalPages = Math.ceil(totalItems / limit);
        const paginatedRows = allRows.slice(skip, skip + limit);

            res.json({
                data: paginatedRows,
                pagination: {
                    currentPage: page,
                    totalPages,
                    totalItems,
                    itemsPerPage: limit,
                    hasNextPage: page < totalPages,
                    hasPreviousPage: page > 1
                }
            });
    } catch (e) {
        console.error("Error fetching quotations:", e);
        res.status(500).json({
            message: "Error fetching quotations",
            error: e.message
        });
    }
}

export default allQuotationController;