import express from 'express';

import bookingFormController from '../../Controller/commonControllers/booking/bookingFormController.js';
import bookingProcessController from '../../Controller/commonControllers/booking/bookingProcessController.js';
import bookingColorController from '../../Controller/commonControllers/booking/bookingColorController.js';
import bookingDetails from '../../Controller/commonControllers/booking/bookingDetailsController.js';
import myBookingPageController from '../../Controller/commonControllers/booking/myBookingPageController.js';
import bookingCancelController from '../../Controller/commonControllers/booking/bookingCancelController.js';
import bookingReqestController from '../../Controller/commonControllers/booking/bookingRequestController.js'
import BookingRequestNotification from '../../Controller/commonControllers/booking/bookingRequestNotification.js';

const bookingRoute = express.Router();

bookingRoute.get('/my-bookings',myBookingPageController);
bookingRoute.get('/booking-form', bookingFormController);
bookingRoute.post('/booking-process', bookingProcessController);
bookingRoute.get('/booking-color', bookingColorController);
bookingRoute.get('/booking-details',bookingDetails);
bookingRoute.get('/booking-cancel',bookingCancelController);
bookingRoute.post('/booking-request',bookingReqestController)
bookingRoute.get('/booking-notification',BookingRequestNotification)

export default bookingRoute;