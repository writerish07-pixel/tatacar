import express from 'express'

import initialFetch from '../../Controller/commonControllers/schemeSheet/initialFetchController.js'
import schemeController from '../../Controller/commonControllers/schemeSheet/schemeController.js';

const schemeSheetRoute = express.Router();

schemeSheetRoute.get('/scheme',initialFetch);
schemeSheetRoute.get('/scheme-data',schemeController);

export default schemeSheetRoute;
