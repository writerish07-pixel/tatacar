import express from 'express'

import dealerController from '../../Controller/commonControllers/stockSheet/dealerController.js'
import plantController from '../../Controller/commonControllers/stockSheet/plantController.js'
import zawlController from '../../Controller/commonControllers/stockSheet/zawlController.js'
import zonalController from '../../Controller/commonControllers/stockSheet/zonalController.js'

const stockSheetRoute = express.Router();

stockSheetRoute.get('/stock/dealership-data', dealerController);
stockSheetRoute.get('/stock/plant-data', plantController);
stockSheetRoute.get('/stock/zawl-data', zawlController);
stockSheetRoute.get('/stock/zonal-data', zonalController);

export default stockSheetRoute;