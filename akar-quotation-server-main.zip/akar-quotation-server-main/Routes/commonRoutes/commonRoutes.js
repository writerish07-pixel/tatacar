import express from 'express'

import { authenticateJWT, checkRole } from '../../middleware/auth.js'

import stockSheetRoute from './stockSheets.js';
import schemeSheetRoute from './schemeSheet.js';
import quotationRoute from './quotationRoute.js';
import pdfRoute from './pdfRoute.js';
import bookingRoute from './bookingRoute.js'
import authRoute from './authRoute.js'

const commonRoute = express.Router();

bookingRoute.use(authenticateJWT);
bookingRoute.use(checkRole(['admin','teamLead','sales']));

// Routes
commonRoute.use(authRoute);
commonRoute.use(stockSheetRoute);
commonRoute.use(schemeSheetRoute);
commonRoute.use(quotationRoute);
commonRoute.use(pdfRoute);
commonRoute.use(bookingRoute);

export default commonRoute;