import express from 'express';

import initialFetch from '../../Controller/commonControllers/quotation/initialFetchController.js';
import quotationController from '../../Controller/commonControllers/quotation/quotationController.js';
import myQuotationController from '../../Controller/commonControllers/quotation/myQuotationController.js';
import paginationMiddleware from '../../middleware/pagination.js';

const quotationRoute = express.Router();

quotationRoute.get('/quotation', initialFetch);
quotationRoute.get('/quotation-data', quotationController);
quotationRoute.get('/my-quotation',paginationMiddleware,myQuotationController)

export default quotationRoute;