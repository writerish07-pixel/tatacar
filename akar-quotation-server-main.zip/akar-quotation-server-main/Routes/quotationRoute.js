import express from 'express';
import { authenticateJWT, checkRole } from '../middleware/auth.js';
import paginationMiddleware from '../middleware/pagination.js';

import myQuotationController from '../Controller/commonControllers/quotation/myQuotationController.js';

const quotationRoute = express.Router();

// Apply authentication and role check to all routes
quotationRoute.use(authenticateJWT);
quotationRoute.use(checkRole(['sales','teamLead']));

quotationRoute.get('/my-quotations', paginationMiddleware, myQuotationController);

export default quotationRoute; 