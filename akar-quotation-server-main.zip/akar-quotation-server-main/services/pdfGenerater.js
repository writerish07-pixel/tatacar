import puppeteer from "puppeteer";
import path from "path";
import { fileURLToPath } from "url";
import { serviceAccountAuth } from "../services/googleSecurityHeader.js";
import { google } from "googleapis";
import randomID from '../mixins/randomID.js';
import { Readable } from "stream";
import fs from "fs/promises";
import sendWhatsapp from "./sendWhatsApp.js";
import Handlebars from "handlebars";

// Register ifCond helper globally
Handlebars.registerHelper("ifCond", function (v1, operator, v2, options) {
  switch (operator) {
    case "==": return v1 == v2 ? options.fn(this) : options.inverse(this);
    case "===": return v1 === v2 ? options.fn(this) : options.inverse(this);
    case "!=": return v1 != v2 ? options.fn(this) : options.inverse(this);
    case "!==": return v1 !== v2 ? options.fn(this) : options.inverse(this);
    case "<": return v1 < v2 ? options.fn(this) : options.inverse(this);
    case "<=": return v1 <= v2 ? options.fn(this) : options.inverse(this);
    case ">": return v1 > v2 ? options.fn(this) : options.inverse(this);
    case ">=": return v1 >= v2 ? options.fn(this) : options.inverse(this);
    case "&&": return v1 && v2 ? options.fn(this) : options.inverse(this);
    case "||": return v1 || v2 ? options.fn(this) : options.inverse(this);
    default: return options.inverse(this);
  }
});

let newPage;

const getPage = async () => {
  if (newPage) return newPage;
  
  const browser = await puppeteer.launch({
    headless: true,
    args: ["--no-sandbox", "--disable-setuid-sandbox"],
  });

  newPage = await browser.newPage();
  return newPage;
}

// ES Module-compatible __dirname
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Read HTML template
const htmlTemplate = await fs.readFile(path.join(__dirname, "template.html"), "utf8");

// Google APIs setup
const drive = google.drive({ version: "v3", auth: serviceAccountAuth });
const sheets = google.sheets({ version: "v4", auth: serviceAccountAuth });

const QUOTATION_FOLDER_ID = "1jsoZz9jDWXMVvL4AIphGok1A7mhKfYET";
const SPREADSHEET_ID = process.env.QUOTE_SHEET_ID;
const SHEET_NAME = "QuotationSheet";

const flattenJSON = (obj, prefix = "") => {
  return Object.keys(obj).reduce((acc, k) => {
    const pre = prefix.length ? `${prefix}.${k}` : k;
    if (typeof obj[k] === "object" && obj[k] !== null && !Array.isArray(obj[k])) {
      Object.assign(acc, flattenJSON(obj[k], pre));
    } else {
      acc[pre] = Array.isArray(obj[k]) ? JSON.stringify(obj[k]) : obj[k];
    }
    return acc;
  }, {});
};

const appendToSheet = async (Qdata) => {
  try {
    const flatData = flattenJSON(Qdata);
    const row = Object.values(flatData);
    console.log(row.length);
    await sheets.spreadsheets.values.append({
      spreadsheetId: SPREADSHEET_ID,
      range: SHEET_NAME,
      valueInputOption: "RAW",
      insertDataOption: "INSERT_ROWS",
      requestBody: { values: [row] },      
    });
  } catch (err) {
    console.error("Error adding to Google Sheet:", err);
  }
};

const uploadToDrive = async (pdfBuffer, filename, folderId) => {
  const fileMetadata = {
    name: filename,
    parents: [folderId],
  };

  const media = {
    mimeType: "application/pdf",
    body: Readable.from(pdfBuffer instanceof Buffer ? [pdfBuffer] : [Buffer.from(pdfBuffer)]),
  };

  const response = await drive.files.create({
    requestBody: fileMetadata,
    media,
    fields: "id",
  });

  return response.data.id;
};

const makeFilePublic = async (fileId) => {
  await drive.permissions.create({
    fileId,
    requestBody: { role: "reader", type: "anyone" },
  });
  return `https://drive.google.com/file/d/${fileId}/view`;
};

const generatePDFBuffer = async (htmlContent) => {
  const page = await getPage();
  await page.setContent(htmlContent);

  const buffer = await page.pdf({
    format: "A3",
    printBackground: true,
    margin: { top: "10mm", bottom: "10mm", left: "10mm", right: "10mm" },
  });

  return buffer;
};

const generatePDF = async (req, res) => {
  const startTime = performance.now();
  try {
    const Qname = req.body.name;
    const Qmobile = req.body.mobile;
    const Qdate = req.body.date;
    const Qbody = req.body;

    const randomId = randomID(Qname, Qmobile, Qdate);
    const Qdata = { quotationID: randomId, ...Qbody };

    const logoPath = path.join(__dirname, 'logo.jpg');
    const logoBuffer = await fs.readFile(logoPath);
    const logoBase64 = logoBuffer.toString('base64');
    const logoSrc = `data:image/png;base64,${logoBase64}`;

    const sealPath = path.join(__dirname, 'seal.png')
    const sealBuffer = await fs.readFile(sealPath);
    const sealBase64 = sealBuffer.toString('base64');
    const sealSrc = `data:image/png;base64,${sealBase64}`;

    // ✅ Compile and fill HTML template using Handlebars
    const template = Handlebars.compile(htmlTemplate);
    const filledHtml = template({ Qdata, logoSrc, sealSrc });

    // ✅ Generate PDF
    const pdfBuffer = await generatePDFBuffer(filledHtml);

    const fileId = await uploadToDrive(pdfBuffer, `${Qdata.name}_${randomId}.pdf`, QUOTATION_FOLDER_ID);
    const publicUrl = await makeFilePublic(fileId);
    const whatsAppUrl = sendWhatsapp(Qdata);
    res.status(200).send({ whatsAppUrl, publicUrl });
    
    Qdata.fileUrl = publicUrl;
    Qdata.waUrl = whatsAppUrl;
    await appendToSheet(Qdata);
  } catch (error) {
    console.error("Error generating or uploading PDF:", error);
    res.status(500).send("Error generating or uploading PDF");
  }
  
  const endTime = performance.now();
  const executionTime = endTime - startTime;

  console.log(`Execution time: ${executionTime} milliseconds`);
};

export default generatePDF;
